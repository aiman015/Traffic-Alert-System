#pragma once
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define RED     "\033[31m"
#define BLUE    "\033[34m"
#define GRAY    "\033[90m"
#include "IEventSubscriber.h"
#include "EventEnvelope.h"
#include <vector>
#include <map>
#include <deque>
#include <string>
#include <memory>
#include <algorithm>
#include <iostream>

// ─────────────────────────────────────────────────────────────
//  EventBus  (Task 1 — Observer Pattern core)
//
//  Acts as the middleman between cameras (publishers) and
//  services (subscribers). Cameras call publish(), services
//  call subscribe(). The bus delivers to every subscriber.
//
//  Key design decisions:
//  • Stores IEventSubscriber* — never concrete classes
//  • Supports per-event-type subscriptions
//  • Adding a 5th event type requires ZERO changes here
//  • Includes a bounded queue (Scenario 2 requirement)
// ─────────────────────────────────────────────────────────────
class EventBus {
public:
    // ── Singleton access (one bus for the whole city) ──
    static EventBus& getInstance() {
        static EventBus instance;
        return instance;
    }

    // ── Subscribe to a specific event type ──
    void subscribe(const std::string& eventType, IEventSubscriber* subscriber) {
        subscribers[eventType].push_back(subscriber);
        std::cout << BLUE << BOLD << "  [EventBus]" << RESET << GREEN << " SUBSCRIBED: " << RESET << subscriber->getName()
                  << " subscribed to " << eventType << "\n";
    }

    // ── Unsubscribe from a specific event type ──
    void unsubscribe(const std::string& eventType, IEventSubscriber* subscriber) {
        auto& list = subscribers[eventType];
        list.erase(std::remove(list.begin(), list.end(), subscriber), list.end());
        std::cout << BLUE << BOLD << "  [EventBus]" << RESET << YELLOW << " UNSUBSCRIBED: " << RESET << subscriber->getName()
                  << " unsubscribed from " << eventType << "\n";
    }

    // ── Publish an event (camera calls this) ──
    //    Envelope is added to the bounded queue, then dispatched.
    void publish(const EventEnvelope& envelope) {
        enqueue(envelope);
        dispatchAll();
    }

    // ── Get current queue size (for testing Scenario 2) ──
    size_t queueSize() const { return eventQueue.size(); }

    // ── Set max queue size (Scenario 2: bounded queue) ──
    void setMaxQueueSize(size_t maxSize) { maxQueueSize = maxSize; }

    // ── Reset (useful between tests) ──
    void reset() {
        subscribers.clear();
        eventQueue.clear();
    }

private:
    EventBus() : maxQueueSize(10000) {}   // Default: 10,000 max
    EventBus(const EventBus&) = delete;
    void operator=(const EventBus&) = delete;

    // ── Priority score: higher = more important ──
    //    CRITICAL congestion > speed violation > vehicle detected > cleared
    int priorityScore(const EventEnvelope& env) const {
        if (env.event_type == "CongestionAlertEvent") {
            // Check severity if possible
            auto* cae = dynamic_cast<CongestionAlertEvent*>(env.payload.get());
            if (cae) {
                if (cae->severityLevel == "CRITICAL") return 100;
                if (cae->severityLevel == "HIGH")     return 80;
                if (cae->severityLevel == "MEDIUM")   return 60;
                return 40;
            }
        }
        if (env.event_type == "SpeedViolationEvent")  return 70;
        if (env.event_type == "VehicleDetectedEvent") return 20;
        if (env.event_type == "TrafficClearedEvent")  return 10;
        return 5;
    }

    // ── Bounded queue: drop LOWEST priority event when full ──
    void enqueue(const EventEnvelope& envelope) {
        if (eventQueue.size() >= maxQueueSize) {
            // Find and remove the least important event
            auto minIt = std::min_element(
                eventQueue.begin(), eventQueue.end(),
                [this](const EventEnvelope& a, const EventEnvelope& b) {
                    return priorityScore(a) < priorityScore(b);
                });
            std::cout << "[EventBus] Queue full! Dropping least-important event: "
                      << minIt->event_type << "\n";
            eventQueue.erase(minIt);
        }
        eventQueue.push_back(envelope);
    }

    // ── Dispatch all queued events to their subscribers ──
    void dispatchAll() {
        while (!eventQueue.empty()) {
            const EventEnvelope& envelope = eventQueue.front();
            auto it = subscribers.find(envelope.event_type);
            if (it != subscribers.end()) {
                for (IEventSubscriber* sub : it->second) {
                    sub->onEvent(envelope);
                }
            }
            eventQueue.pop_front();
        }
    }

    std::map<std::string, std::vector<IEventSubscriber*>> subscribers;
    std::deque<EventEnvelope> eventQueue;
    size_t maxQueueSize;
};