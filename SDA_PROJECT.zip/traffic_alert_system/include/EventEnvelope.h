#pragma once
#include "Events.h"
#include <string>
#include <memory>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <random>
#include <iostream>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"

inline std::string generateUUID() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis(0, 15);
    static std::uniform_int_distribution<> dis2(8, 11);
    std::stringstream ss;
    ss << std::hex;
    for (int i = 0; i < 8; i++)  ss << dis(gen);
    ss << "-";
    for (int i = 0; i < 4; i++)  ss << dis(gen);
    ss << "-4";
    for (int i = 0; i < 3; i++)  ss << dis(gen);
    ss << "-";
    ss << dis2(gen);
    for (int i = 0; i < 3; i++)  ss << dis(gen);
    ss << "-";
    for (int i = 0; i < 12; i++) ss << dis(gen);
    return ss.str();
}

inline std::string currentTimestamp() {
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&t), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

struct EventEnvelope {
    std::string event_id;
    std::string correlation_id;
    int         schema_version;
    std::string source_id;
    std::string timestamp;
    std::string event_type;
    std::shared_ptr<BaseEvent> payload;

    EventEnvelope(std::string sourceId,
                  std::shared_ptr<BaseEvent> event,
                  std::string correlationId = "",
                  int version = 1)
        : event_id(generateUUID()),
          correlation_id(correlationId.empty() ? generateUUID() : correlationId),
          schema_version(version),
          source_id(std::move(sourceId)),
          timestamp(currentTimestamp()),
          event_type(event->eventType()),
          payload(std::move(event))
    {}

    EventEnvelope(std::string eventId,
                  std::string sourceId,
                  std::shared_ptr<BaseEvent> event,
                  std::string correlationId = "",
                  int version = 1)
        : event_id(std::move(eventId)),
          correlation_id(correlationId.empty() ? generateUUID() : correlationId),
          schema_version(version),
          source_id(std::move(sourceId)),
          timestamp(currentTimestamp()),
          event_type(event->eventType()),
          payload(std::move(event))
    {}

    void print() const {
        std::cout << "\n"
                  << BLUE << "  +-----------------------------------------------+\n"
                  << "  |  EventEnvelope                                |\n"
                  << "  +-----------------------------------------------+\n" << RESET
                  << "  |  event_id       : " << event_id       << "\n"
                  << "  |  correlation_id : " << correlation_id << "\n"
                  << "  |  schema_version : " << schema_version << "\n"
                  << "  |  source_id      : " << source_id      << "\n"
                  << "  |  timestamp      : " << timestamp       << "\n"
                  << "  |  event_type     : " << event_type      << "\n"
                  << BLUE << "  +-----------------------------------------------+\n" << RESET << "\n";
    }
};