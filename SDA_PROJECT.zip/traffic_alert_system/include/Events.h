#pragma once
#include <string>

// ─────────────────────────────────────────────
//  Base Event
// ─────────────────────────────────────────────
struct BaseEvent {
    virtual ~BaseEvent() = default;
    virtual std::string eventType() const = 0;
};

// Event 1: VehicleDetectedEvent
struct VehicleDetectedEvent : public BaseEvent {
    std::string cameraId;
    std::string vehiclePlate;
    std::string timestamp;
    VehicleDetectedEvent(std::string cam, std::string plate, std::string ts)
        : cameraId(std::move(cam)), vehiclePlate(std::move(plate)), timestamp(std::move(ts)) {}
    std::string eventType() const override { return "VehicleDetectedEvent"; }
};

// Event 2: SpeedViolationEvent
struct SpeedViolationEvent : public BaseEvent {
    std::string cameraId;
    std::string vehiclePlate;
    double speedDetected;
    double speedLimit;
    std::string timestamp;
    SpeedViolationEvent(std::string cam, std::string plate,
                        double detected, double limit, std::string ts)
        : cameraId(std::move(cam)), vehiclePlate(std::move(plate)),
          speedDetected(detected), speedLimit(limit), timestamp(std::move(ts)) {}
    std::string eventType() const override { return "SpeedViolationEvent"; }
};

// Event 3: CongestionAlertEvent
struct CongestionAlertEvent : public BaseEvent {
    std::string intersectionId;
    int vehicleCount;
    std::string severityLevel;
    std::string timestamp;
    CongestionAlertEvent(std::string intersection, int count,
                         std::string severity, std::string ts)
        : intersectionId(std::move(intersection)), vehicleCount(count),
          severityLevel(std::move(severity)), timestamp(std::move(ts)) {}
    std::string eventType() const override { return "CongestionAlertEvent"; }
};

// Event 4: TrafficClearedEvent
struct TrafficClearedEvent : public BaseEvent {
    std::string intersectionId;
    std::string timestamp;
    TrafficClearedEvent(std::string intersection, std::string ts)
        : intersectionId(std::move(intersection)), timestamp(std::move(ts)) {}
    std::string eventType() const override { return "TrafficClearedEvent"; }
};

// ─────────────────────────────────────────────
//  Event 5: WrongWayDrivingEvent  (NEW)
//  Published when: camera detects vehicle
//  driving against traffic flow
//  Subscribers: Alert, Dashboard, Logging
//
//  Adding this required ZERO changes to
//  EventBus, cameras, or existing services.
// ─────────────────────────────────────────────
struct WrongWayDrivingEvent : public BaseEvent {
    std::string cameraId;
    std::string vehiclePlate;
    std::string roadId;
    std::string timestamp;
    WrongWayDrivingEvent(std::string cam, std::string plate,
                         std::string road, std::string ts)
        : cameraId(std::move(cam)), vehiclePlate(std::move(plate)),
          roadId(std::move(road)), timestamp(std::move(ts)) {}
    std::string eventType() const override { return "WrongWayDrivingEvent"; }
};