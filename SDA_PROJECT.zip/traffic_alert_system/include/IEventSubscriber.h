#pragma once
#include "EventEnvelope.h"
#include "Statistics.h"
#include <unordered_set>
#include <string>
#include <iostream>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define YELLOW  "\033[33m"

class IEventSubscriber {
public:
    virtual ~IEventSubscriber() = default;
    virtual void onEvent(const EventEnvelope& envelope) = 0;
    virtual std::string getName() const = 0;
};

class IdempotentSubscriber : public IEventSubscriber {
public:
    void onEvent(const EventEnvelope& envelope) override final {
        if (seenEventIds.count(envelope.event_id)) {
            // Only count once per event (not per subscriber)
            if (getName() == "AlertService")
                getStats().totalDuplicatesBlocked++;
            std::cout << YELLOW << "  [" << getName()
                      << "] DUPLICATE blocked -- event_id: "
                      << envelope.event_id << RESET << "\n";
            return;
        }
        seenEventIds.insert(envelope.event_id);
        processEvent(envelope);
    }
protected:
    virtual void processEvent(const EventEnvelope& envelope) = 0;
private:
    std::unordered_set<std::string> seenEventIds;
};