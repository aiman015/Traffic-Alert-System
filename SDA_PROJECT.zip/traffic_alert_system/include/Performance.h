#pragma once
#include <iostream>
#include <chrono>
#include <string>
#include <vector>
#include <numeric>
#include <algorithm>
#include <iomanip>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"

class PerformanceMonitor {
public:
    using Clock = std::chrono::high_resolution_clock;
    using TimePoint = std::chrono::time_point<Clock>;

    void startTimer() { startTime = Clock::now(); }

    void stopTimer(const std::string& eventType) {
        auto end = Clock::now();
        double ms = std::chrono::duration<double, std::milli>(end - startTime).count();
        responseTimes.push_back(ms);
        eventLabels.push_back(eventType);
        std::cout << YELLOW << "  [Performance] Response time: "
                  << std::fixed << std::setprecision(3)
                  << ms << " ms" << RESET << "\n";
    }

    void printReport() const {
        if (responseTimes.empty()) {
            std::cout << "  No events measured yet. Publish some events first.\n";
            return;
        }

        double avg = std::accumulate(responseTimes.begin(), responseTimes.end(), 0.0)
                     / responseTimes.size();
        double mn  = *std::min_element(responseTimes.begin(), responseTimes.end());
        double mx  = *std::max_element(responseTimes.begin(), responseTimes.end());

        std::cout << std::fixed << std::setprecision(3);
        std::cout << "\n  Events measured : " << responseTimes.size() << "\n";
        std::cout << GREEN  << "  Min response    : " << mn  << " ms\n" << RESET;
        std::cout << YELLOW << "  Avg response    : " << avg << " ms\n" << RESET;
        std::cout << RED    << "  Max response    : " << mx  << " ms\n" << RESET;

        std::cout << "\n  " << BOLD << "Per-event breakdown:\n" << RESET;
        for (size_t i = 0; i < responseTimes.size(); i++) {
            std::cout << "    [" << (i+1) << "] "
                      << std::left << std::setw(28) << eventLabels[i]
                      << ": " << responseTimes[i] << " ms\n";
        }
    }

private:
    TimePoint startTime;
    std::vector<double> responseTimes;
    std::vector<std::string> eventLabels;
};

inline PerformanceMonitor& getPerfMonitor() {
    static PerformanceMonitor pm;
    return pm;
}