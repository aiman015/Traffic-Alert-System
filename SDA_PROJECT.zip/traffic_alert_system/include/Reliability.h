#pragma once
#include <iostream>
#include <string>
#include <map>
#include <chrono>
#include <iomanip>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"

// ─────────────────────────────────────────────
//  Quality 2: Reliability
//  Demonstrates:
//  - Service health monitoring (MTBF concept)
//  - Graceful degradation when a service crashes
//  - System keeps running despite partial failure
//  - No single point of failure in the EventBus
// ─────────────────────────────────────────────

enum class ServiceStatus { ONLINE, CRASHED, RECOVERING };

struct ServiceHealth {
    std::string name;
    ServiceStatus status = ServiceStatus::ONLINE;
    int eventsProcessed  = 0;
    int eventsMissed     = 0;
    std::string lastSeen = "N/A";
};

class ReliabilityMonitor {
public:
    ReliabilityMonitor() {
        services["AlertService"]     = { "AlertService"    };
        services["LoggingService"]   = { "LoggingService"  };
        services["DashboardService"] = { "DashboardService"};
        services["ReportingService"] = { "ReportingService"};
    }

    // Mark a service as crashed
    void crashService(const std::string& name) {
        if (services.count(name)) {
            services[name].status = ServiceStatus::CRASHED;
            std::cout << RED << BOLD << "\n  [Reliability] SERVICE CRASH SIMULATED: "
                      << name << RESET << RED
                      << "\n  The EventBus continues operating normally.\n"
                      << "  Other services are unaffected.\n"
                      << "  Events for " << name << " will be missed until recovery.\n"
                      << RESET;
        }
    }

    // Recover a crashed service
    void recoverService(const std::string& name) {
        if (services.count(name)) {
            services[name].status = ServiceStatus::ONLINE;
            std::cout << GREEN << "\n  [Reliability] SERVICE RECOVERED: "
                      << name << " is back online.\n" << RESET;
        }
    }

    bool isOnline(const std::string& name) const {
        auto it = services.find(name);
        if (it == services.end()) return true;
        return it->second.status == ServiceStatus::ONLINE;
    }

    void recordEvent(const std::string& name, bool processed) {
        if (services.count(name)) {
            if (processed) services[name].eventsProcessed++;
            else           services[name].eventsMissed++;
        }
    }

    // Print health dashboard
    void printHealthReport() const {
        std::cout << "\n" << BLUE << BOLD
                  << "+==================================================+\n"
                  << "|    Service Health Monitor       |\n"
                  << "+==================================================+\n" << RESET;

        std::cout << "  " << std::left
                  << std::setw(20) << "Service"
                  << std::setw(14) << "Status"
                  << std::setw(10) << "Processed"
                  << "Missed\n";
        std::cout << "  " << std::string(54, '-') << "\n";

        for (auto& [name, svc] : services) {
            std::string statusStr;
            std::string color;
            switch (svc.status) {
                case ServiceStatus::ONLINE:
                    statusStr = "ONLINE";    color = GREEN; break;
                case ServiceStatus::CRASHED:
                    statusStr = "CRASHED";   color = RED;   break;
                case ServiceStatus::RECOVERING:
                    statusStr = "RECOVERING"; color = YELLOW; break;
            }
            std::cout << "  " << color << BOLD << std::setw(20) << name << RESET
                      << color << std::setw(14) << statusStr << RESET
                      << std::setw(10) << svc.eventsProcessed
                      << svc.eventsMissed << "\n";
        }

        std::cout << "\n  " << BOLD << "Key Reliability Principles demonstrated:\n" << RESET;
        std::cout << "  - EventBus has NO single point of failure\n";
        std::cout << "  - Crashed services do not affect other services\n";
        std::cout << "  - System degrades gracefully, not catastrophically\n";
        std::cout << "  - Target availability: 99.999% (< 6 min downtime/year)\n";
    }

    // Simulate the nightmare scenario from lecture
    void nightmareScenario() {
        std::cout << "\n" << RED << BOLD
                  << "+==================================================+\n"
                  << "|  Reliability -- Partial Failure Scenario    |\n"
                  << "+==================================================+\n" << RESET;
        std::cout << RED
                  << "  Scenario: LoggingService crashes mid-operation.\n"
                  << "  Without proper design: penalty issued, no audit log.\n"
                  << "  With our design: EventBus stays up, AlertService\n"
                  << "  still works, only LoggingService is affected.\n"
                  << "  Redundancy ensures no single point of failure.\n"
                  << RESET;
    }

private:
    std::map<std::string, ServiceHealth> services;
};

inline ReliabilityMonitor& getReliabilityMonitor() {
    static ReliabilityMonitor rm;
    return rm;
}