#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <thread>
#include <chrono>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"

// ─────────────────────────────────────────────
//  Quality 4: Scalability
//  Demonstrates:
//  - Vertical vs Horizontal scaling concept
//  - Adding processing nodes without rebuild
//  - Queue growth analysis at different loads
//  - Peak load handling (football match scenario)
// ─────────────────────────────────────────────

struct ProcessingNode {
    std::string nodeId;
    int capacity;        // events/sec this node can handle
    bool active;
};

class ScalabilityManager {
public:
    ScalabilityManager() {
        // Start with 1 node (initial deployment)
        nodes.push_back({ "NODE-01", 80, true });
    }

    // ── Add a processing node (Horizontal Scaling) ──
    void addNode() {
        int id = nodes.size() + 1;
        std::string nodeId = "NODE-0" + std::to_string(id);
        nodes.push_back({ nodeId, 80, true });
        std::cout << GREEN << "  [Scalability] Horizontal scale-out: "
                  << nodeId << " added.\n"
                  << "  Total capacity: " << getTotalCapacity()
                  << " events/sec\n" << RESET;
    }

    // ── Remove a node ──
    void removeNode() {
        if (nodes.size() > 1) {
            std::string removed = nodes.back().nodeId;
            nodes.pop_back();
            std::cout << YELLOW << "  [Scalability] Node " << removed
                      << " removed. Total capacity: "
                      << getTotalCapacity() << " events/sec\n" << RESET;
        } else {
            std::cout << RED << "  Cannot remove last node.\n" << RESET;
        }
    }

    int getTotalCapacity() const {
        int total = 0;
        for (auto& n : nodes) if (n.active) total += n.capacity;
        return total;
    }

    // ── Vertical vs Horizontal comparison ──
    void printScalingComparison() const {
        std::cout << "\n" << BLUE << BOLD
                  << "+==================================================+\n"
                  << "|  Vertical vs Horizontal Scaling|\n"
                  << "+==================================================+\n" << RESET;

        std::cout << "\n  " << BOLD << std::left
                  << std::setw(28) << "Aspect"
                  << std::setw(18) << "Vertical Scaling"
                  << "Horizontal Scaling\n" << RESET;
        std::cout << "  " << std::string(62, '-') << "\n";

        auto row = [](const std::string& a, const std::string& v, const std::string& h,
                      const char* vc = nullptr, const char* hc = nullptr) {
            std::cout << "  " << std::left << std::setw(28) << a;
            if (vc) std::cout << vc;
            std::cout << std::setw(18) << v;
            if (vc) std::cout << RESET;
            if (hc) std::cout << hc;
            std::cout << h;
            if (hc) std::cout << RESET;
            std::cout << "\n";
        };

        row("Method",          "Upgrade one server",     "Add more servers");
        row("Cost",            "Expensive hardware",     "Commodity machines",   RED, GREEN);
        row("Ceiling",         "Has hard limit",         "Virtually unlimited",  RED, GREEN);
        row("Downtime needed", "Yes",                    "No",                   RED, GREEN);
        row("Our system",      "Not used",               "Preferred approach",   RED, GREEN);

        std::cout << "\n  " << BOLD << "Current System Nodes:\n" << RESET;
        for (auto& n : nodes) {
            std::cout << "    " << (n.active ? GREEN : RED)
                      << n.nodeId << " -- " << n.capacity
                      << " events/sec -- "
                      << (n.active ? "ACTIVE" : "INACTIVE")
                      << RESET << "\n";
        }
        std::cout << "  " << BOLD << "  Total Capacity: "
                  << GREEN << getTotalCapacity() << " events/sec\n" << RESET;
    }

    // ── Peak load analysis (football match) ──
    void peakLoadAnalysis() const {
        std::cout << "\n" << BLUE << BOLD
                  << "+==================================================+\n"
                  << "|  Peak Load Analysis    |\n"
                  << "+==================================================+\n" << RESET;

        int incomingRate = 500;
        int capacity     = getTotalCapacity();
        int netGrowth    = incomingRate - capacity;

        std::cout << "\n  Scenario: Football match near stadium\n\n";
        std::cout << "  Incoming rate    : " << incomingRate << " events/sec\n";
        std::cout << "  System capacity  : " << capacity << " events/sec ("
                  << nodes.size() << " node(s))\n";

        if (netGrowth > 0) {
            double timeToFill = 10000.0 / netGrowth;
            std::cout << RED << "  Net queue growth : +" << netGrowth << " events/sec\n";
            std::cout << "  Queue fills in   : " << std::fixed << std::setprecision(1)
                      << timeToFill << " seconds\n" << RESET;
            std::cout << YELLOW << "  Action needed    : Add more nodes!\n" << RESET;
        } else {
            std::cout << GREEN << "  Net queue growth : " << netGrowth
                      << " (system can handle load)\n"
                      << "  No queue overflow at current scale.\n" << RESET;
        }

        // Show how adding nodes helps
        std::cout << "\n  " << BOLD << "Scaling simulation:\n" << RESET;
        int cap = 80;
        for (int n = 1; n <= 7; n++) {
            int growth = incomingRate - cap;
            std::string status;
            const char* color;
            if (growth > 0) { status = "OVERLOADED"; color = RED; }
            else            { status = "STABLE";     color = GREEN; }

            std::cout << "    " << n << " node(s) = " << cap << " events/sec -- "
                      << color << status << RESET << "\n";
            cap += 80;
            if (growth <= 0) break;
        }
    }

private:
    std::vector<ProcessingNode> nodes;
};

inline ScalabilityManager& getScalabilityManager() {
    static ScalabilityManager sm;
    return sm;
}