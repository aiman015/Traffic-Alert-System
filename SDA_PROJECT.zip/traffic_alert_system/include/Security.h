#pragma once
#include <string>
#include <map>
#include <iostream>
#include <limits>
#include <algorithm>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"
#define CYAN    "\033[36m"

enum class Role { ADMIN, OPERATOR, VIEWER };

struct User {
    std::string username;
    std::string password;
    Role role;
};

class SecurityManager {
public:
    SecurityManager() {
        users["admin"]    = { "admin",    "admin123",  Role::ADMIN    };
        users["operator"] = { "operator", "op456",     Role::OPERATOR };
        users["viewer"]   = { "viewer",   "view789",   Role::VIEWER   };
    }

    // Step 1: Show role menu and return choice
  int getRoleChoice() {
    std::cout << "\n" << BLUE << BOLD
              << "+==================================================+\n"
              << "|              SELECT YOUR ROLE                    |\n"
              << "+==================================================+\n" << RESET
              << "\n"
              << "  " << CYAN << "[1]" << RESET << " Admin     -- full access\n"
              << "  " << CYAN << "[2]" << RESET << " Operator  -- publish events + view stats\n"
              << "  " << CYAN << "[3]" << RESET << " Viewer    -- view stats only\n"
              << "  " << BOLD << "[0]" << RESET << " Exit system\n"
              << "\n  Select role: ";
    int c; std::cin >> c;
    return c;
}
    // Step 2: Login for selected role
    bool loginWithRole(int roleChoice) {
        std::string expectedUser;
        switch (roleChoice) {
            case 1: expectedUser = "admin";    break;
            case 2: expectedUser = "operator"; break;
            case 3: expectedUser = "viewer";   break;
            default:
                std::cout << RED << "  Invalid role.\n" << RESET;
                return false;
        }

        std::cout << "\n" << BLUE << BOLD
                  << "+==================================================+\n"
                  << "|                    LOGIN                         |\n"
                  << "+==================================================+\n" << RESET << "\n";

        int attempts = 0;
        while (attempts < 3) {
            std::string uname, pass;
            std::cout << "  Username: "; std::cin >> uname;
            std::cout << "  Password: "; std::cin >> pass;

            auto it = users.find(uname);
            if (it != users.end() && it->second.password == pass) {
                // Check role matches selection
                Role expected = roleChoice == 1 ? Role::ADMIN :
                                roleChoice == 2 ? Role::OPERATOR : Role::VIEWER;
                if (it->second.role != expected) {
                    std::cout << RED << "  Credentials do not match selected role.\n" << RESET;
                    attempts++;
                    continue;
                }
                currentUser = it->second;
                loggedIn = true;
                std::cout << GREEN << "\n  Login successful. Welcome, "
                          << currentUser.username << "!\n" << RESET;
                return true;
            }
            attempts++;
            std::cout << RED << "  Incorrect credentials. "
                      << (3 - attempts) << " attempt(s) left.\n" << RESET;
        }
        std::cout << RED << BOLD << "  Access denied. Too many failed attempts.\n" << RESET;
        return false;
    }

    // Authorization checks
    bool canPublishEvents()   const { return currentUser.role == Role::ADMIN || currentUser.role == Role::OPERATOR; }
    bool canViewStats()       const { return loggedIn; }
    bool canRunSimulation()   const { return currentUser.role == Role::ADMIN || currentUser.role == Role::OPERATOR; }
    bool canRunDuplicateTest() const { return currentUser.role == Role::ADMIN; }

    bool checkAccess(const std::string& action) const {
        bool allowed = false;
        if (action == "publish")   allowed = canPublishEvents();
        if (action == "stats")     allowed = canViewStats();
        if (action == "simulate")  allowed = canRunSimulation();
        if (action == "duplicate") allowed = canRunDuplicateTest();
        if (!allowed)
            std::cout << RED << "\n  Access denied: your role does not have permission for this action.\n" << RESET;
        return allowed;
    }

    // Input validation
    static bool validatePlate(const std::string& p) {
        if (p.size() < 3 || p.size() > 10) return false;
        for (char c : p) if (!isalnum(c) && c != '-') return false;
        return true;
    }
    static bool validateCameraId(const std::string& id) {
        return id.size() >= 3 && id.size() <= 10;
    }
    static bool validateSpeed(double s)  { return s > 0 && s < 400; }
    static bool validateVehicleCount(int c) { return c > 0 && c <= 10000; }
    static bool validateSeverity(const std::string& s) {
        return s == "LOW" || s == "MEDIUM" || s == "HIGH" || s == "CRITICAL";
    }

    std::string getCurrentUser() const { return currentUser.username; }
    std::string roleName() const {
        switch (currentUser.role) {
            case Role::ADMIN:    return "ADMIN";
            case Role::OPERATOR: return "OPERATOR";
            case Role::VIEWER:   return "VIEWER";
        }
        return "";
    }

private:
    std::map<std::string, User> users;
    User currentUser;
    bool loggedIn = false;
};