#pragma once
#include "IEventSubscriber.h"
#include "Events.h"
#include "Statistics.h"
#include <iostream>
#include <string>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"

// ─────────────────────────────────────────────
//  AlertService
//  Listens: SpeedViolationEvent, WrongWayDrivingEvent
// ─────────────────────────────────────────────
class AlertService : public IdempotentSubscriber {
public:
    int penaltyCount = 0;
    std::string getName() const override { return "AlertService"; }
protected:
    void processEvent(const EventEnvelope& envelope) override {
        if (envelope.event_type == "SpeedViolationEvent") {
            auto* e = dynamic_cast<SpeedViolationEvent*>(envelope.payload.get());
            if (!e) return;
            penaltyCount++;
            getStats().totalPenaltiesIssued++;
            std::cout << RED << BOLD << "  [AlertService]" << RESET
                      << " PENALTY #" << penaltyCount
                      << " | Vehicle: " << e->vehiclePlate
                      << " | Speed: " << RED << e->speedDetected << " km/h" << RESET
                      << " | Limit: " << e->speedLimit << " km/h"
                      << " | Camera: " << e->cameraId << "\n";

        } else if (envelope.event_type == "WrongWayDrivingEvent") {
            auto* e = dynamic_cast<WrongWayDrivingEvent*>(envelope.payload.get());
            if (!e) return;
            penaltyCount++;
            getStats().totalPenaltiesIssued++;
            std::cout << RED << BOLD << "  [AlertService]" << RESET
                      << RED << " !! WRONG-WAY ALERT !!" << RESET
                      << " | Vehicle: " << e->vehiclePlate
                      << " | Road: " << e->roadId
                      << " | Camera: " << e->cameraId << "\n";
        }
    }
};

// ─────────────────────────────────────────────
//  LoggingService
//  Listens: SpeedViolation, Congestion, WrongWay
// ─────────────────────────────────────────────
class LoggingService : public IdempotentSubscriber {
public:
    int logCount = 0;
    std::string getName() const override { return "LoggingService"; }
protected:
    void processEvent(const EventEnvelope& envelope) override {
        logCount++;
        std::cout << "  [LoggingService]"
                  << " LOG #" << logCount
                  << " | " << envelope.event_type
                  << " | src: " << envelope.source_id
                  << " | " << envelope.timestamp << "\n";
    }
};

// ─────────────────────────────────────────────
//  DashboardService
//  Listens: VehicleDetected, Congestion,
//           TrafficCleared, WrongWayDriving
// ─────────────────────────────────────────────
class DashboardService : public IdempotentSubscriber {
public:
    std::string getName() const override { return "DashboardService"; }
protected:
    void processEvent(const EventEnvelope& envelope) override {
        if (envelope.event_type == "VehicleDetectedEvent") {
            auto* e = dynamic_cast<VehicleDetectedEvent*>(envelope.payload.get());
            if (e) std::cout << "  [DashboardService]"
                             << " MAP: Vehicle " << e->vehiclePlate
                             << " at " << e->cameraId << "\n";

        } else if (envelope.event_type == "CongestionAlertEvent") {
            auto* e = dynamic_cast<CongestionAlertEvent*>(envelope.payload.get());
            if (e) std::cout << RED << BOLD << "  [DashboardService]" << RESET
                             << RED << " CONGESTION at " << e->intersectionId
                             << " [" << e->severityLevel << "] "
                             << e->vehicleCount << " vehicles" << RESET << "\n";

        } else if (envelope.event_type == "TrafficClearedEvent") {
            auto* e = dynamic_cast<TrafficClearedEvent*>(envelope.payload.get());
            if (e) std::cout << GREEN << "  [DashboardService]"
                             << " CLEARED: " << e->intersectionId << RESET << "\n";

        } else if (envelope.event_type == "WrongWayDrivingEvent") {
            auto* e = dynamic_cast<WrongWayDrivingEvent*>(envelope.payload.get());
            if (e) std::cout << RED << BOLD << "  [DashboardService]" << RESET
                             << RED << " WRONG-WAY on " << e->roadId
                             << " | Vehicle: " << e->vehiclePlate << RESET << "\n";
        }
    }
};

// ─────────────────────────────────────────────
//  ReportingService
//  Listens: VehicleDetected, SpeedViolation
// ─────────────────────────────────────────────
class ReportingService : public IdempotentSubscriber {
public:
    std::string getName() const override { return "ReportingService"; }
protected:
    void processEvent(const EventEnvelope& envelope) override {
        if (envelope.event_type == "VehicleDetectedEvent") {
            getStats().totalVehiclesDetected++;
            std::cout << "  [ReportingService] Vehicle count: "
                      << getStats().totalVehiclesDetected << "\n";
        } else if (envelope.event_type == "SpeedViolationEvent") {
            getStats().totalSpeedViolations++;
            std::cout << "  [ReportingService] Violation count: "
                      << getStats().totalSpeedViolations << "\n";
        }
    }
};