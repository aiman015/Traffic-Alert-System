#pragma once
#include <iostream>
#include <string>
#include <map>

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"

// ─────────────────────────────────────────────
//  Statistics — global counters tracked
//  across the entire session
// ─────────────────────────────────────────────
struct Statistics {
    int totalVehiclesDetected  = 0;
    int totalSpeedViolations   = 0;
    int totalPenaltiesIssued   = 0;
    int totalCongestionAlerts  = 0;
    int totalTrafficCleared    = 0;
    int totalWrongWayEvents    = 0;
    int totalDuplicatesBlocked = 0;
    int totalEventsPublished   = 0;
    std::map<std::string, int> cameraActivity;  // per-camera event count

    void print() const {
        std::cout << "\n" << BLUE << BOLD
                  << "+==================================================+\n"
                  << "|           SESSION STATISTICS DASHBOARD           |\n"
                  << "+==================================================+\n" << RESET;

        std::cout << "\n  " << BOLD << "Event Counts:\n" << RESET;
        row("Total events published",     totalEventsPublished);
        row("Vehicles detected",          totalVehiclesDetected);
        row("Speed violations",           totalSpeedViolations,   RED);
        row("Congestion alerts",          totalCongestionAlerts,  RED);
        row("Traffic cleared events",     totalTrafficCleared,    GREEN);
        row("Wrong-way driving alerts",   totalWrongWayEvents,    RED);

        std::cout << "\n  " << BOLD << "Enforcement:\n" << RESET;
        row("Penalties issued",           totalPenaltiesIssued,   YELLOW);
        row("Duplicate events blocked",   totalDuplicatesBlocked, GREEN);

        if (!cameraActivity.empty()) {
            std::cout << "\n  " << BOLD << "Camera Activity:\n" << RESET;
            for (auto& [cam, count] : cameraActivity) {
                std::cout << "    " << cam << " : " << count << " events\n";
            }
        }

        std::cout << "\n" << BLUE
                  << "+==================================================+\n" << RESET << "\n";
    }

private:
    void row(const std::string& label, int value,
             const char* color = nullptr) const {
        std::cout << "    " << std::left;
        std::cout.width(34);
        std::cout << label << ": ";
        if (color) std::cout << color << BOLD;
        std::cout << value;
        if (color) std::cout << RESET;
        std::cout << "\n";
    }
};

// Global stats instance
inline Statistics& getStats() {
    static Statistics s;
    return s;
}