#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <algorithm>
#include <vector>

#include "EventBus.h"
#include "EventEnvelope.h"
#include "Services.h"
#include "Statistics.h"
#include "Security.h"
#include "Performance.h"

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"
#define CYAN    "\033[36m"

std::string now() {
    auto t = std::chrono::system_clock::now();
    std::time_t tt = std::chrono::system_clock::to_time_t(t);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&tt), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

void sleepMs(int ms) {
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

std::string toUpper(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::toupper);
    return s;
}
// Generate deterministic event_id from event content
std::string contentBasedId(const std::string& cam, const std::string& plate,
                            const std::string& eventType, const std::string& extra = "") {
    std::string raw = cam + "|" + plate + "|" + eventType + "|" + extra;
    // Simple hash — same input always produces same ID
    std::size_t h = std::hash<std::string>{}(raw);
    std::stringstream ss;
    ss << std::hex << h << "-" << h * 2654435761ULL;
    return "EVT-" + ss.str();
}
void section(const std::string& t) {
    std::cout << "\n" << BLUE << BOLD
              << "+==================================================+\n"
              << "|  " << t;
    int pad = 48 - (int)t.size();
    for (int i = 0; i < pad; i++) std::cout << " ";
    std::cout << "|\n+==================================================+"
              << RESET << "\n";
}

void publish(EventBus& bus, const std::string& camId,
             std::shared_ptr<BaseEvent> event,
             const std::string& corrId) {
    getStats().totalEventsPublished++;
    getStats().cameraActivity[camId]++;
    if (event->eventType() == "CongestionAlertEvent")  getStats().totalCongestionAlerts++;
    else if (event->eventType() == "TrafficClearedEvent") getStats().totalTrafficCleared++;
    else if (event->eventType() == "WrongWayDrivingEvent") getStats().totalWrongWayEvents++;
    getPerfMonitor().startTimer();
    EventEnvelope env(camId, event, corrId);
    bus.publish(env);
    getPerfMonitor().stopTimer(event->eventType());
}

void doVehicleDetected(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("publish")) return;
    section("Simulate Vehicle Detected");
    std::string cam, plate;
    std::cout << "  Camera ID (e.g. CAM-001): "; std::cin >> cam;
    std::cout << "  Vehicle plate           : "; std::cin >> plate;
    if (!SecurityManager::validateCameraId(cam)) {
        std::cout << RED << "  Invalid camera ID.\n" << RESET; return;
    }
    if (!SecurityManager::validatePlate(plate)) {
        std::cout << RED << "  Invalid plate format.\n" << RESET; return;
    }
    auto e = std::make_shared<VehicleDetectedEvent>(cam, plate, now());
    publish(bus, cam, e, "");
}

void doSpeedViolation(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("publish")) return;
    section("Simulate Speed Violation");
    std::string cam, plate;
    double speed, limit;
    std::cout << "  Camera ID : "; std::cin >> cam;
    std::cout << "  Plate     : "; std::cin >> plate;
    std::cout << "  Speed (km/h): "; std::cin >> speed;
    std::cout << "  Limit (km/h): "; std::cin >> limit;
    if (!SecurityManager::validateSpeed(speed) || !SecurityManager::validateSpeed(limit)) {
        std::cout << RED << "  Invalid speed value.\n" << RESET; return;
    }
    if (speed <= limit) {
        std::cout << GREEN << "  No violation.\n" << RESET; return;
    }
    auto e = std::make_shared<SpeedViolationEvent>(cam, plate, speed, limit, now());
    std::string eid = contentBasedId(cam, plate, "SpeedViolationEvent", std::to_string((int)speed));
    EventEnvelope env(eid, cam, e, "");
    getStats().totalEventsPublished++;
    getStats().cameraActivity[cam]++;
    getPerfMonitor().startTimer();
    bus.publish(env);
    getPerfMonitor().stopTimer("SpeedViolationEvent");
}

void doCongestionAlert(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("publish")) return;
    section("Simulate Congestion Alert");
    std::string intersection, severity;
    int count;
    std::cout << "  Intersection ID: "; std::cin >> intersection;
    std::cout << "  Vehicle count  : "; std::cin >> count;
    std::cout << "  Severity (low/medium/high/critical): "; std::cin >> severity;
    severity = toUpper(severity);
    if (!SecurityManager::validateVehicleCount(count)) {
        std::cout << RED << "  Invalid count.\n" << RESET; return;
    }
    if (!SecurityManager::validateSeverity(severity)) {
        std::cout << RED << "  Invalid severity.\n" << RESET; return;
    }
    auto e = std::make_shared<CongestionAlertEvent>(intersection, count, severity, now());
    publish(bus, "CAM-SYS", e, "");
}

void doTrafficCleared(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("publish")) return;
    section("Simulate Traffic Cleared");
    std::string intersection;
    std::cout << "  Intersection ID: "; std::cin >> intersection;
    auto e = std::make_shared<TrafficClearedEvent>(intersection, now());
    publish(bus, "CAM-SYS", e, "");
}

void doWrongWay(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("publish")) return;
    section("Simulate Wrong-Way Driving");
    std::string cam, plate, road;
    std::cout << "  Camera ID: "; std::cin >> cam;
    std::cout << "  Plate    : "; std::cin >> plate;
    std::cout << "  Road ID  : "; std::cin >> road;
    if (!SecurityManager::validateCameraId(cam) || !SecurityManager::validatePlate(plate)) {
        std::cout << RED << "  Invalid input.\n" << RESET; return;
    }
    auto e = std::make_shared<WrongWayDrivingEvent>(cam, plate, road, now());
    std::string eid = contentBasedId(cam, plate, "WrongWayDrivingEvent", road);
    EventEnvelope env(eid, cam, e, "");
    getStats().totalEventsPublished++;
    getStats().cameraActivity[cam]++;
    getPerfMonitor().startTimer();
    bus.publish(env);
    getPerfMonitor().stopTimer("WrongWayDrivingEvent");
}

void doDuplicateTest(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("duplicate")) return;
    section("Duplicate Event Blocking Test");

    std::cout << "  Enter the speed violation details to test duplicate blocking:\n\n";

    std::string cam, plate;
    double speed, limit;
    std::cout << "  Camera ID   : "; std::cin >> cam;
    std::cout << "  Plate       : "; std::cin >> plate;
    std::cout << "  Speed (km/h): "; std::cin >> speed;
    std::cout << "  Limit (km/h): "; std::cin >> limit;

    if (!SecurityManager::validateSpeed(speed) || !SecurityManager::validateSpeed(limit)) {
        std::cout << RED << "  Invalid speed value.\n" << RESET; return;
    }
    if (speed <= limit) {
        std::cout << GREEN << "  No violation -- speed within limit.\n" << RESET; return;
    }

    // Generate one fixed event_id for both publishes
    auto e = std::make_shared<SpeedViolationEvent>(cam, plate, speed, limit, now());
    std::string fixedId = generateUUID();

    std::cout << "\n  Publishing event (1st time)...\n";
    std::cout << "  event_id = " << fixedId << "\n\n";
    EventEnvelope env1(fixedId, cam, e, "DUP-TEST");
    getStats().totalEventsPublished++;
    getPerfMonitor().startTimer();
    bus.publish(env1);
    getPerfMonitor().stopTimer("SpeedViolationEvent");

    std::cout << "\n  Press Enter to publish the SAME event again (duplicate test)...";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cin.get();

    std::cout << "\n  Publishing same event (2nd time -- DUPLICATE)...\n";
    std::cout << "  event_id = " << fixedId << " (same as above!)\n\n";
    EventEnvelope env2(fixedId, cam, e, "DUP-TEST");
    getStats().totalEventsPublished++;
    bus.publish(env2);

    std::cout << "\n" << GREEN << "  Result: Duplicate blocked. Only one penalty issued. [PASS]\n" << RESET;
}

void runSimulation(EventBus& bus, SecurityManager& sec) {
    if (!sec.checkAccess("simulate")) return;
    section("Full City Simulation -- Morning Rush Hour");
    std::cout << "  Simulating busy city traffic...\n\n";
    sleepMs(400);

    struct SE { int d; std::string l, c; std::shared_ptr<BaseEvent> e; };
    std::vector<SE> tl = {
        {500,"CAM-001: Vehicle detected","CAM-001",std::make_shared<VehicleDetectedEvent>("CAM-001","ABC-1234",now())},
        {600,"CAM-002: Speed violation -- XYZ-5678 at 118 km/h","CAM-002",std::make_shared<SpeedViolationEvent>("CAM-002","XYZ-5678",118.0,80.0,now())},
        {500,"CAM-003: Vehicle detected","CAM-003",std::make_shared<VehicleDetectedEvent>("CAM-003","DEF-9999",now())},
        {600,"INT-07: CRITICAL congestion -- 92 vehicles","CAM-SYS",std::make_shared<CongestionAlertEvent>("INT-07",92,"CRITICAL",now())},
        {500,"CAM-004: Speed violation -- MNO-1111 at 145 km/h","CAM-004",std::make_shared<SpeedViolationEvent>("CAM-004","MNO-1111",145.0,100.0,now())},
        {500,"CAM-003: Wrong-way driving -- DEF-9999 on RD-M2","CAM-003",std::make_shared<WrongWayDrivingEvent>("CAM-003","DEF-9999","RD-M2",now())},
        {600,"INT-03: HIGH congestion -- 67 vehicles","CAM-SYS",std::make_shared<CongestionAlertEvent>("INT-03",67,"HIGH",now())},
        {700,"INT-07: Traffic cleared","CAM-SYS",std::make_shared<TrafficClearedEvent>("INT-07",now())},
        {500,"CAM-001: Speed violation -- PQR-7777 at 95 km/h","CAM-001",std::make_shared<SpeedViolationEvent>("CAM-001","PQR-7777",95.0,60.0,now())},
        {600,"INT-03: Traffic cleared","CAM-SYS",std::make_shared<TrafficClearedEvent>("INT-03",now())},
    };

    for (auto& ev : tl) {
        sleepMs(ev.d);
        std::cout << CYAN << "  [" << now() << "] " << RESET << ev.l << "\n";
        publish(bus, ev.c, ev.e, "SIM-CORR");
        std::cout << "\n";
    }
    std::cout << GREEN << BOLD << "  Simulation complete.\n" << RESET;
}

void showPerformanceReport() {
    section("Performance Report");
    getPerfMonitor().printReport();
}