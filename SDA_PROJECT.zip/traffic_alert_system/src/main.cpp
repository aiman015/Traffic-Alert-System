#include <iostream>
#include <limits>
#include "EventBus.h"
#include "Services.h"
#include "Security.h"
#include "Statistics.h"
#include "Performance.h"

#ifdef _WIN32
#include <windows.h>
#endif

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define BLUE    "\033[34m"
#define GREEN   "\033[32m"
#define RED     "\033[31m"
#define YELLOW  "\033[33m"
#define CYAN    "\033[36m"

void enableColors() {
#ifdef _WIN32
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    GetConsoleMode(hOut, &dwMode);
    SetConsoleMode(hOut, dwMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
#endif
}

// Clear screen
void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Press enter to continue
void pressEnter() {
    std::cout << "\n" << BLUE << "  Press Enter to return to menu..." << RESET;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cin.get();
}

// Declared in actions.cpp
void doVehicleDetected(EventBus&, SecurityManager&);
void doSpeedViolation(EventBus&, SecurityManager&);
void doCongestionAlert(EventBus&, SecurityManager&);
void doTrafficCleared(EventBus&, SecurityManager&);
void doWrongWay(EventBus&, SecurityManager&);
void doDuplicateTest(EventBus&, SecurityManager&);
void runSimulation(EventBus&, SecurityManager&);
void showPerformanceReport();

void printBanner() {
    std::cout << BLUE << BOLD
              << "\n+==================================================+\n"
              << "|      USER-DRIVEN TRAFFIC ALERT SYSTEM            |\n"
              << "+==================================================+\n" << RESET;
}

void printAdminMenu(const std::string& user) {
    clearScreen();
    printBanner();
    std::cout << "\n" << BLUE << BOLD
              << "+==================================================+\n"
              << "|            ADMIN CONTROL PANEL                   |\n"
              << "+==================================================+\n" << RESET
              << "  Logged in as: " << BOLD << user << "  [ADMIN]\n" << RESET
              << "  --------------------------------------------------\n"
              << "  " << CYAN   << "[1]" << RESET << " Simulate vehicle detected\n"
              << "  " << CYAN   << "[2]" << RESET << " Simulate speed violation\n"
              << "  " << CYAN   << "[3]" << RESET << " Simulate congestion alert\n"
              << "  " << CYAN   << "[4]" << RESET << " Simulate traffic cleared\n"
              << "  " << RED    << "[5]" << RESET << " Simulate wrong-way driving\n"
              << "  --------------------------------------------------\n"
              << "  " << YELLOW << "[6]" << RESET << " Test duplicate event blocking\n"
              << "  " << GREEN  << "[7]" << RESET << " Run full city simulation\n"
              << "  " << BOLD   << "[8]" << RESET << " Statistics dashboard\n"
              << "  " << BOLD   << "[9]" << RESET << " Performance report\n"
              << "  " << BOLD   << "[0]" << RESET << " Logout\n"
              << "\n  Enter choice: ";
}

void printOperatorMenu(const std::string& user) {
    clearScreen();
    printBanner();
    std::cout << "\n" << BLUE << BOLD
              << "+==================================================+\n"
              << "|           OPERATOR CONTROL PANEL                 |\n"
              << "+==================================================+\n" << RESET
              << "  Logged in as: " << BOLD << user << "  [OPERATOR]\n" << RESET
              << "  --------------------------------------------------\n"
              << "  " << CYAN  << "[1]" << RESET << " Simulate vehicle detected\n"
              << "  " << CYAN  << "[2]" << RESET << " Simulate speed violation\n"
              << "  " << CYAN  << "[3]" << RESET << " Simulate congestion alert\n"
              << "  " << CYAN  << "[4]" << RESET << " Simulate traffic cleared\n"
              << "  " << RED   << "[5]" << RESET << " Simulate wrong-way driving\n"
               << "  --------------------------------------------------\n"
              << "  " << GREEN << "[6]" << RESET << " Run full city simulation\n"
              << "  " << BOLD  << "[7]" << RESET << " Statistics dashboard\n"
              << "  " << BOLD  << "[8]" << RESET << " Performance report\n"
              << "  " << BOLD  << "[0]" << RESET << " Logout\n"
              << "\n  Enter choice: ";
}

void printViewerMenu(const std::string& user) {
    clearScreen();
    printBanner();
    std::cout << "\n" << BLUE << BOLD
              << "+==================================================+\n"
              << "|            VIEWER PANEL                          |\n"
              << "+==================================================+\n" << RESET
              << "  Logged in as: " << BOLD << user << "  [VIEWER]\n" << RESET
              << "  --------------------------------------------------\n"
              << "  " << BOLD << "[1]" << RESET << " Statistics dashboard\n"
              << "  " << BOLD << "[2]" << RESET << " Performance report\n"
              << "  " << BOLD << "[0]" << RESET << " Logout\n"
              << "\n  Enter choice: ";
}

void runAdminLoop(EventBus& bus, SecurityManager& sec) {
    int c = -1;
    while (c != 0) {
        printAdminMenu(sec.getCurrentUser());
        if (!(std::cin >> c)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            continue;
        }
        clearScreen();
        switch (c) {
            case 1: doVehicleDetected(bus, sec); pressEnter(); break;
            case 2: doSpeedViolation(bus, sec);  pressEnter(); break;
            case 3: doCongestionAlert(bus, sec); pressEnter(); break;
            case 4: doTrafficCleared(bus, sec);  pressEnter(); break;
            case 5: doWrongWay(bus, sec);        pressEnter(); break;
            case 6: doDuplicateTest(bus, sec);   pressEnter(); break;
            case 7: runSimulation(bus, sec);     pressEnter(); break;
            case 8: getStats().print();           pressEnter(); break;
            case 9: showPerformanceReport();      pressEnter(); break;
            case 0:
                clearScreen();
                std::cout << BLUE << BOLD << "\n  Logged out successfully.\n" << RESET;
                break;
            default: std::cout << RED << "  Invalid choice.\n" << RESET;
        }
    }
}

void runOperatorLoop(EventBus& bus, SecurityManager& sec) {
    int c = -1;
    while (c != 0) {
        printOperatorMenu(sec.getCurrentUser());
        if (!(std::cin >> c)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            continue;
        }
        clearScreen();
        switch (c) {
            case 1: doVehicleDetected(bus, sec); pressEnter(); break;
            case 2: doSpeedViolation(bus, sec);  pressEnter(); break;
            case 3: doCongestionAlert(bus, sec); pressEnter(); break;
            case 4: doTrafficCleared(bus, sec);  pressEnter(); break;
            case 5: doWrongWay(bus, sec);        pressEnter(); break;
            case 6: runSimulation(bus, sec);     pressEnter(); break;
            case 7: getStats().print();           pressEnter(); break;
            case 8: showPerformanceReport();      pressEnter(); break;
            case 0:
                clearScreen();
                std::cout << BLUE << BOLD << "\n  Logged out successfully.\n" << RESET;
                break;
            default: std::cout << RED << "  Invalid choice.\n" << RESET;
        }
    }
}

void runViewerLoop(EventBus& bus, SecurityManager& sec) {
    int c = -1;
    while (c != 0) {
        printViewerMenu(sec.getCurrentUser());
        if (!(std::cin >> c)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            continue;
        }
        clearScreen();
        switch (c) {
            case 1: getStats().print();      pressEnter(); break;
            case 2: showPerformanceReport(); pressEnter(); break;
            case 0:
                clearScreen();
                std::cout << BLUE << BOLD << "\n  Logged out successfully.\n" << RESET;
                break;
            default: std::cout << RED << "  Invalid choice.\n" << RESET;
        }
    }
}

int main() {
    enableColors();

    // Setup EventBus and services silently
    EventBus& bus = EventBus::getInstance();
    AlertService     alertSvc;
    LoggingService   loggingSvc;
    DashboardService dashSvc;
    ReportingService reportSvc;

    printBanner();
    bus.subscribe("VehicleDetectedEvent",  &dashSvc);
    bus.subscribe("VehicleDetectedEvent",  &reportSvc);
    bus.subscribe("SpeedViolationEvent",   &alertSvc);
    bus.subscribe("SpeedViolationEvent",   &loggingSvc);
    bus.subscribe("SpeedViolationEvent",   &reportSvc);
    bus.subscribe("CongestionAlertEvent",  &dashSvc);
    bus.subscribe("CongestionAlertEvent",  &loggingSvc);
    bus.subscribe("TrafficClearedEvent",   &dashSvc);
    bus.subscribe("WrongWayDrivingEvent",  &alertSvc);
    bus.subscribe("WrongWayDrivingEvent",  &dashSvc);
    bus.subscribe("WrongWayDrivingEvent",  &loggingSvc);

    std::cout << "\n  System initialized. Press Enter to continue...";
    std::cin.get();

    // Main loop — returns to role selection after logout
  // Main loop — returns to role selection after logout
while (true) {
    clearScreen();
    printBanner();
    SecurityManager sec;
    int roleChoice = sec.getRoleChoice();

    if (roleChoice == 0) {
        clearScreen();
        printBanner();
        std::cout << BLUE << BOLD << "\n  System shutting down. Goodbye.\n\n" << RESET;
        break;
    }

    if (!sec.loginWithRole(roleChoice)) {
        pressEnter();
        continue;
    }

    clearScreen();
    printBanner();
    std::cout << GREEN << "\n  Login successful. Welcome, "
              << sec.getCurrentUser() << "!\n" << RESET;
    std::cout << "\n  Press Enter to open your panel...";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cin.get();

    switch (roleChoice) {
        case 1: runAdminLoop(bus, sec);    break;
        case 2: runOperatorLoop(bus, sec); break;
        case 3: runViewerLoop(bus, sec);   break;
    }
}
    return 0;
}